export const MARCHA = [
  {
    marcha: 'NORMAL',
    cve: 1
  },
  {
    marcha: 'CLAUDICANTE',
    cve: 2
  },
  {
    marcha: 'ATÁXICA',
    cve: 2
  }
];

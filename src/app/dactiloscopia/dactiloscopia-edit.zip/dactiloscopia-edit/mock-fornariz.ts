export const FORNARIZ = [
  {
    nom: 'RESPINGADA',
    cve: 1
  },
  {
    nom: 'LARGA',
    cve: 2
  },
  {
    nom: 'AGUILEÑA',
    cve: 3
  },
  {
    nom: 'TORCIDA',
    cve: 4
  },
  {
    nom: 'CORTA',
    cve: 5
  }
];

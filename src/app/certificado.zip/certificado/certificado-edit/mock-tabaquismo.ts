export const TABAQUISMO = [
  {
    tabaquismo: 'SI',
    cve: 1
  },
  {
    tabaquismo: 'NO',
    cve: 2
  }
];

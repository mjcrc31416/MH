export const GRADO = [
  {
    grado: '0',
    cve: 1
  },
  {
    grado: '1',
    cve: 2
  },
  {
    grado: '2',
    bid: 3
  },
  {
    grado: '3',
    bid: 4
  }
];

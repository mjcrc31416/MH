export const TAMNRIZ = [
  {
    nom: 'CHICA',
    cve: 1
  },
  {
    nom: 'MEDIANA',
    cve: 2
  },
  {
    nom: 'GRANDE',
    cve: 3
  }
];

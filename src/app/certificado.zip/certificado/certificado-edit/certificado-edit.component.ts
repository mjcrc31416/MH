import { Component, OnInit, ViewChild } from '@angular/core';
import {ActionBarItemModel, barActions} from '../../shared/action-bar2/action-bar-model';
import {FormBuilder, Validators} from '@angular/forms';
import {SnackSrvService} from '../../services/snack-srv.service';
import {ActivatedRoute, ParamMap, Router} from '@angular/router';
import {CertifEvents, CertificadoService} from '../certificado.service';
import {ActionBar2Component} from '../../shared/action-bar2/action-bar2.component';
import * as _ from 'lodash';
import {Subscription} from 'rxjs';
import {MatDialog} from '@angular/material';
import { NumberSequence } from 'ag-grid-community';
import {EventoFactory} from '../../modelFactories/evento-factory';
import { CERTIFICADO } from '../certificado-edit/mock-certificados';
import { PRACTICA } from '../certificado-edit/mock-practica';
import { ALIENTO } from '../certificado-edit/mock-aliento';
import { GRADO } from '../certificado-edit/mock-grado';
import { INTOXICACION } from '../certificado-edit/mock-intoxicacion';
import { MARCHA } from '../certificado-edit/mock-marcha';
import { ROMBERG } from '../certificado-edit/mock-romberg';
import { TOXICOMANIA } from '../certificado-edit/mock-toxicomania';
import { TABAQUISMO } from '../certificado-edit/mock-tabaquismo';
import { ALCOHOLISMO } from '../certificado-edit/mock-alcoholismo';
import { ALERGIAS } from '../certificado-edit/mock-alergias';
import { ENFERMEDADES } from '../certificado-edit/mock-enfermedades';
import { OROFARINGE } from '../certificado-edit/mock-orofaringe';
import { CARDIO } from '../certificado-edit/mock-cardio';
import { ABDOMEN } from '../certificado-edit/mock-abdomen';
import { GENITALES } from '../certificado-edit/mock-genitales';
import { ALTERACIONES } from '../certificado-edit/mock-alteraciones';
import { EXTREMIDADES } from '../certificado-edit/mock-extremidades';
import { LESIONES } from '../certificado-edit/mock-lesiones';
import { PERFORACIONES } from '../certificado-edit/mock-perforaciones';
import { SEXO } from '../certificado-edit/mock-sexo';
import {FormUtilsService} from '../../shared/form-utils.service';
import {TimeInputComponent} from '../../shared/time-input/time-input.component';

@Component({
  selector: 'app-certificado-edit',
  templateUrl: './certificado-edit.component.html',
  styleUrls: ['./certificado-edit.component.scss']
})
export class CertificadoEditComponent implements OnInit {

  sexo = SEXO;
  tcertificado = CERTIFICADO;
  practica = PRACTICA;
  aliento = ALIENTO;
  grado = GRADO;
  intetil = INTOXICACION;
  marcha = MARCHA;
  romberg = ROMBERG;
  toxicomania = TOXICOMANIA;
  tabaquismo = TABAQUISMO;
  alcoholismo = ALCOHOLISMO;
  alergias = ALERGIAS;
  enfermedades = ENFERMEDADES;
  orofaringe = OROFARINGE;
  cardiopul = CARDIO;
  abdomen = ABDOMEN;
  genitales = GENITALES;
  alteraciones = ALTERACIONES;
  extremidades = EXTREMIDADES;
  lesiones = LESIONES;
  perforaciones = PERFORACIONES;

  // Atributos ======================================================================
  _id = null;
  form = this.fb.group({
    folioInterno: [{value: '', disabled: true},],
    fopers: [''],
    nombre: [{value: '', disabled: true},],
    appat: [{value: '', disabled: true},],
    apmat: [{value: '', disabled: true},],
    edad: [''],
    sexo: [''],
    ocupacion: [''],
    lugproc: [''],
    tcertificado: [''],
    fecer: [''],
    practica: [''],
    aliento: [''],
    grado: [''],
    otros: [''],
    intetil: [''],
    pupilas: [''],
    marcha: [''],
    lenguaje: [''],
    estado: [''],
    actitud: [''],
    toxicomania: [''],
    toxi: [''],
    alcoholismo: [''],
    alergias: [''],
    alerg: [''],
    enfermedades: [''],
    enfcro: [''],
    parterial: [''],
    fcardiaca: [''],
    frespiratoria: [''],
    temperatura: [''],
    rpupilares: [''],
    tatuajes: [''],
    perforaciones: [''],
    perfo: [''],
    observaciones: [''],
    orofaringe: [''],
    orofa: [''],
    cardiopul: [''],
    cardio: [''],
    abdomen: [''],
    abdo: [''],
    genitales: [''],
    alteraciones: [''],
    alter: [''],
    extremidades: [''],
    extre: [''],
    lesiones: [''],
    lesi: [''],
    ncertifica: [''],
    cedula: [''],
    feter: ['', Validators.required],
  });
  
    // Constructor and Events ===============================================================
    constructor(
      private snackSrv: SnackSrvService,
      private route: ActivatedRoute,
      private fb: FormBuilder,
      public dialog: MatDialog,
      private router: Router,
      private certificadoSrv: CertificadoService,
      private eventoFct: EventoFactory,
      private formUtils: FormUtilsService,
    ) {
      this.subs.add(
        this.certificadoSrv.eventSource$.subscribe((data) => {
          this.dispatchEvents(data);
          }
        ));
    }
  /*constructor(
    private snackSrv: SnackSrvService,
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    public dialog: MatDialog,
    private certificadoSrv: CertificadoService,
    private eventoFct: EventoFactory
  ) {
    this.subs.add(
      this.certificadoSrv.eventSource$.subscribe((data) => {
        this.dispatchEvents(data);
        }
      ));
  }*/
  
  @ViewChild('actionBar2Comp', {static: false}) public  actionBar2: ActionBar2Component;
  @ViewChild('timeComp', {static: false}) public  timeComp: TimeInputComponent;
  private subs: Subscription = new Subscription();
  eventDocumentList = [];
  orgData = null;
  titlesList = ['Certificado Médico', 'Edición'];
  showActionList = [1, 4];
  isSavingData = false;
  mostrarPanel = true;
  isEdit = false;

  // Action Bar Events ====================================================================

  onActionClicked(item: ActionBarItemModel) {
    if (item.id === barActions.show) {
      // this.toogleMostar();
    }

    if (item.id === barActions.save) {
      this.attemptSave();
    }

    if (item.id === barActions.exit) {
      // if (!this.isSavingData) {
      //   // this.atttemptApprove();
      // }
      console.log('action exit');
      this.onExit();
    }

    if (item.id === barActions.send) {
      if (!this.isSavingData) {
        // this.atttemptApprove();
      }
    }
  }

  onExit() {
    this.router.navigate(['detenidos-cons']);
  }

      // COMPONENT BEHAVIOR ===================================================================
   
      attemptSave() {
        console.log('attemptSave');
        if (!this.isSavingData) {
          if (this.form.valid) {
            console.log('Is valid!');
            const eventoData = this.form.getRawValue();
            console.log(eventoData);

            eventoData.fecha = this.formUtils.getDateFromDateTime({
              feter: eventoData.feter,
              hora: this.timeComp.getData().hora,
              minutos: this.timeComp.getData().minutos,
            });
    
            if (!_.isNil(this._id)) {
              eventoData._id = this._id;
            }
    
            this.certificadoSrv.upsertCertificado(eventoData);
          } else {
            this.snackSrv.showMsg('Faltan campos obligatorios');
          }
    
          this.isSavingData = false;
        }//endIf
      }
  
      /*  attemptSave() {
        console.log('attemptSave');
        if (this.form.valid) {
          console.log('Is valid!');
          const eventoData = this.form.getRawValue();
          console.log(eventoData);
    
          if (!_.isNil(this._id)) {
            eventoData._id = this._id;
          }
    
          this.certificadoSrv.upsertCertificado(eventoData);
        } else {
          this.snackSrv.showMsg('Faltan campos obligatorios');
          this.isSavingData = false;
        }
      }

  onExit() {
    this.router.navigate(['detenidos-cons']);
  }*/

  ngOnInit() {
    const tempProm = this.route.paramMap.subscribe( (params: ParamMap) => {
      console.log(params);
      const id = params.get('id');

      if (id && id !== '0') {
        // Obtener del servidor
        // this.ctrlSrv.getEventById(id);
        // this.eventoSrv.getEventoById(id);
        // this.isEdit = true;
        this._id = id;
      } else {
        // Es un nuevo elemento de captura
        // this.ctrlSrv.newEvent();
        // this.newItemDefaults();
      }
    });

    this.certificadoSrv.getAllCatalogo(this._id);

  }

  ngOnDestroy(): void {
    if (this.subs) {
      this.subs.unsubscribe();
    }
  }


  findComboValue(listData, setObjData, attributeName) {
    for (let data of listData) {
      if (data[attributeName] === setObjData[attributeName]) {
        return data;
        break;
      }
    }
  }

  // SERVICE EVENTS =======================================================================
  dispatchEvents(data) {
    console.log('dispatchEvents');
    // Evento
    if (data.event === CertifEvents.DetCatalog) {
      console.log(data);
      if (data.data) {
        const response = data.data;
        console.log(response.detenido);
        console.log(response.preIph);

        //this.sexo = response[0].sexo;
         this.form.patchValue(response.detenido[0]);
         this.form.patchValue(response.preIph[0]);
   
         let tmpForm = this.form.getRawValue();
   
         this.setFullDate(this.formUtils.getDateAndTimeObj(data.feter));
         this.orgData = data.data[0];

      }

      if (this._id) {
        this.certificadoSrv.getById(this._id);
      }

      /*if (this._id) {
        this.certificadoSrv.getAllCatalog(this._id);
      }*/
      return;
    }//endIf

    if (data.event === CertifEvents.UpsertCertificado) {
      console.log(data);
      if (data.data) {
        this._id = data.data._id;
        this.snackSrv.showMsg('Información guardada correctamente');
      }
      return;
    }//endIf

    /*if (data.event === EventoEvents.UpsertCertificado) {
      console.log(data);
      if (!_.isNil(data)) {
        this.snackSrv.showMsg('Información guardada correctamente!');
        this._id = data.data._id;
      }

      this.isSavingData = false;
    }*/

    if (data.event === CertifEvents.GetByIdDone) {
      console.log('EventoEvents.GetCertificadoById ==========================');
      console.log(data);
      if (data.data) {
        const response = data.data;
        console.log(response);

        this.form.patchValue(response);

        let tmpForm = this.form.getRawValue();

        console.log(this.sexo);
        const dat01 = this.formUtils.findComboValue(this.sexo, tmpForm.sexo, 'sexo', 'sexo');
        console.log(dat01);
        this.form.get('sexo').patchValue(dat01);
      
        console.log(this.tcertificado);
        const dat02 = this.formUtils.findComboValue(this.tcertificado, tmpForm.tcertificado, 'tcertificado', 'tcertificado');
        console.log(dat02);
        this.form.get('tcertificado').patchValue(dat02);

        console.log(this.practica);
        const dat03 = this.formUtils.findComboValue(this.practica, tmpForm.practica, 'practica', 'practica');
        console.log(dat03);
        this.form.get('practica').patchValue(dat03);

        console.log(this.aliento);
        const dat04 = this.formUtils.findComboValue(this.aliento, tmpForm.aliento, 'aliento', 'aliento');
        console.log(dat04);
        this.form.get('aliento').patchValue(dat04);
  
        console.log(this.grado);
        const dat05 = this.formUtils.findComboValue(this.grado, tmpForm.grado, 'grado', 'grado');
        console.log(dat05);
        this.form.get('grado').patchValue(dat05);
  
        console.log(this.intetil);
        const dat06 = this.formUtils.findComboValue(this.intetil, tmpForm.intetil, 'intetil', 'intetil');
        console.log(dat06);
        this.form.get('intetil').patchValue(dat06);
  
        console.log(this.marcha);
        const dat07 = this.formUtils.findComboValue(this.marcha, tmpForm.marcha, 'marcha', 'marcha');
        console.log(dat07);
        this.form.get('marcha').patchValue(dat07);
  
        console.log(this.toxicomania);
        const dat09 = this.formUtils.findComboValue(this.toxicomania, tmpForm.toxicomania, 'toxicomania', 'toxicomania');
        console.log(dat09);
        this.form.get('toxicomania').patchValue(dat09);
  
        console.log(this.alcoholismo);
        const dat11 = this.formUtils.findComboValue(this.alcoholismo, tmpForm.alcoholismo, 'alcoholismo', 'alcoholismo');
        console.log(dat11);
        this.form.get('alcoholismo').patchValue(dat11);
  
        console.log(this.alergias);
        const dat12 = this.formUtils.findComboValue(this.alergias, tmpForm.alergias, 'alergias', 'alergias');
        console.log(dat12);
        this.form.get('alergias').patchValue(dat12);
  
        console.log(this.enfermedades);
        const dat13 = this.formUtils.findComboValue(this.enfermedades, tmpForm.enfermedades, 'enfermedades', 'enfermedades');
        console.log(dat13);
        this.form.get('enfermedades').patchValue(dat13);
  
        console.log(this.orofaringe);
        const dat14 = this.formUtils.findComboValue(this.orofaringe, tmpForm.orofaringe, 'orofaringe', 'orofaringe');
        console.log(dat14);
        this.form.get('orofaringe').patchValue(dat14);
  
        console.log(this.cardiopul);
        const dat15 = this.formUtils.findComboValue(this.cardiopul, tmpForm.cardiopul, 'cardiopul', 'cardiopul');
        console.log(dat15);
        this.form.get('cardiopul').patchValue(dat15);
  
        console.log(this.abdomen);
        const dat16 = this.formUtils.findComboValue(this.abdomen, tmpForm.abdomen, 'abdomen', 'abdomen');
        console.log(dat16);
        this.form.get('abdomen').patchValue(dat16);
  
        console.log(this.genitales);
        const dat17 = this.formUtils.findComboValue(this.genitales, tmpForm.genitales, 'genitales', 'genitales');
        console.log(dat17);
        this.form.get('genitales').patchValue(dat17);
  
        console.log(this.alteraciones);
        const dat18 = this.formUtils.findComboValue(this.alteraciones, tmpForm.alteraciones, 'alteraciones', 'alteraciones');
        console.log(dat18);
        this.form.get('alteraciones').patchValue(dat18);
  
        console.log(this.extremidades);
        const dat19 = this.formUtils.findComboValue(this.extremidades, tmpForm.extremidades, 'extremidades', 'extremidades');
        console.log(dat19);
        this.form.get('extremidades').patchValue(dat19);
  
        console.log(this.lesiones);
        const dat20 = this.formUtils.findComboValue(this.lesiones, tmpForm.lesiones, 'lesiones', 'lesiones');
        console.log(dat20);
        this.form.get('lesiones').patchValue(dat20);
  
        console.log(this.perforaciones);
        const dat21 = this.formUtils.findComboValue(this.perforaciones, tmpForm.perforaciones, 'perforaciones', 'perforaciones');
        console.log(dat21);
        this.form.get('perforaciones').patchValue(dat21);
      
      }

    }
  }

 // COMPONENT AND USER CONTROL FUNCTIONS =================================================
 setForm(data) {
  this.form.get('sexo').patchValue(data.sexo);
  this.form.get('tcertificado').patchValue(data.tcertificado);
  this.form.get('practica').patchValue(data.practica);
  this.form.get('aliento').patchValue(data.aliento);
  this.form.get('grado').patchValue(data.grado);
  this.form.get('intetil').patchValue(data.intetil);
  this.form.get('marcha').patchValue(data.marcha);
  this.form.get('romberg').patchValue(data.romberg);
  this.form.get('toxicomania').patchValue(data.toxicomania);
  this.form.get('tabaquismo').patchValue(data.tabaquismo);
  this.form.get('alcoholismo').patchValue(data.alcoholismo);
  this.form.get('alergias').patchValue(data.alergias);
  this.form.get('enfermedades').patchValue(data.enfermedades);
  this.form.get('orofaringe').patchValue(data.orofaringe);
  this.form.get('cardiopul').patchValue(data.cardiopul);
  this.form.get('genitales').patchValue(data.genitales);
  this.form.get('alteraciones').patchValue(data.alteraciones);
  this.form.get('abdomen').patchValue(data.abdomen);
  this.form.get('extremidades').patchValue(data.extremidades);
  this.form.get('lesiones').patchValue(data.lesiones);
  this.form.get('perforaciones').patchValue(data.perforaciones);

  this.sexo.forEach((item) => {
    // console.log(item);
    if (data.sexo && item.bid === data.sexo.bid) {
      this.form.get('sexo').patchValue(item);
      return false;
    }
  });
  this.tcertificado.forEach((item) => {
    // console.log(item);
    if (data.tcertificado && item.bid === data.tcertificado.bid) {
      this.form.get('tcertificado').patchValue(item);
      return false;
    }
  });
  this.practica.forEach((item) => {
    // console.log(item);
    if (data.practica.cve) {
      this.form.get('practica').patchValue(item);
      return false;
    }
  });
  this.aliento.forEach((item) => {
    // console.log(item);
    if (data.aliento && item.cve === data.aliento.cve) {
      this.form.get('aliento').patchValue(item);
      return false;
    }
  });
  this.grado.forEach((item) => {
    // console.log(item);
    if (data.grado && item.cve === data.grado.cve) {
      this.form.get('grado').patchValue(item);
      return false;
    }
  });
  this.intetil.forEach((item) => {
    // console.log(item);
    if (data.intetil && item.cve === data.intetil.cve) {
      this.form.get('intetil').patchValue(item);
      return false;
    }
  });
  this.marcha.forEach((item) => {
    // console.log(item);
    if (data.marcha && item.cve === data.marcha.cve) {
      this.form.get('marcha').patchValue(item);
      return false;
    }
  }); 
 this.romberg.forEach((item) => {
    // console.log(item);
    if (data.romberg && item.cve === data.romberg.cve) {
      this.form.get('romberg').patchValue(item);
      return false;
    }
  });
  this.toxicomania.forEach((item) => {
    // console.log(item);
    if (data.toxicomania && item.cve === data.toxicomania.cve) {
      this.form.get('toxicomania').patchValue(item);
      return false;
    }
  });
  this.tabaquismo.forEach((item) => {
    // console.log(item);
    if (data.tabaquismo && item.cve === data.tabaquismo.cve) {
      this.form.get('tabaquismo').patchValue(item);
      return false;
    }
  });
  this.alcoholismo.forEach((item) => {
    // console.log(item);
    if (data.alcoholismo && item.cve === data.alcoholismo.cve) {
      this.form.get('alcoholismo').patchValue(item);
      return false;
    }
  });
  this.alergias.forEach((item) => {
    // console.log(item);
    if (data.alergias && item.cve === data.alergias.cve) {
      this.form.get('alergias').patchValue(item);
      return false;
    }
  });
  this.enfermedades.forEach((item) => {
    // console.log(item);
    if (data.enfermedades && item.cve === data.enfermedades.cve) {
      this.form.get('enfermedades').patchValue(item);
      return false;
    }
  });
  this.orofaringe.forEach((item) => {
    // console.log(item);
    if (data.orofaringe && item.cve === data.orofaringe.cve) {
      this.form.get('orofaringe').patchValue(item);
      return false;
    }
  });
  this.cardiopul.forEach((item) => {
    // console.log(item);
    if (data.cardiopul && item.bid === data.cardiopul.bid) {
      this.form.get('cardiopul').patchValue(item);
      return false;
    }
  });
  this.genitales.forEach((item) => {
    // console.log(item);
    if (data.genitales && item.cve === data.genitales.cve) {
      this.form.get('genitales').patchValue(item);
      return false;
    }
  });
  this.alteraciones.forEach((item) => {
    // console.log(item);
    if (data.alteraciones && item.cve === data.alteraciones.cve) {
      this.form.get('alteraciones').patchValue(item);
      return false;
    }
  });
  this.abdomen.forEach((item) => {
    // console.log(item);
    if (data.abdomen && item.cve === data.abdomen.cve) {
      this.form.get('abdomen').patchValue(item);
      return false;
    }
  });
  this.extremidades.forEach((item) => {
    // console.log(item);
    if (data.extremidades && item.cve === data.extremidades.cve) {
      this.form.get('extremidades').patchValue(item);
      return false;
    }
  });
  this.lesiones.forEach((item) => {
    // console.log(item);
    if (data.lesiones && item.cve === data.lesiones.cve) {
      this.form.get('lesiones').patchValue(item);
      return false;
    }
  });
  this.perforaciones.forEach((item) => {
    // console.log(item);
    if (data.perforaciones && item.cve === data.perforaciones.cve) {
      this.form.get('perforaciones').patchValue(item);
      return false;
    }
  });
 {
    // se supone que es el evento de edicion
  }

  console.log(this.certificadoSrv);

}// setForm <<<<

setFullDate(feterObj) {
  console.log('setFullDate =========================');
  console.log(feterObj);
  this.form.get('feter').patchValue(feterObj.feterObj);
  this.timeComp.setByDateTimeObj(feterObj);
}

}

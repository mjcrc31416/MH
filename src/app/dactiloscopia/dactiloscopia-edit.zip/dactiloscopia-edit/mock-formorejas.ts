export const FORMOREJAS = [
  {
    nom: 'PERFORADO',
    cve: 1
  },
  {
    nom: 'FOSETA',
    cve: 2
  },
  {
    nom: 'ISLOTE',
    cve: 3
  },
  {
    nom: 'HUYENTE',
    cve: 4
  }
];

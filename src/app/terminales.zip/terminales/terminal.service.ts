import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
//import {LogServiceService} from '../shared/log-service.service';
import {LogServiceService} from '../shared/log-service.service';



// @Injectable({
//   providedIn: 'root'
// })

export enum TerminalEvents {
  UpsertDone = 1,
  GetById = 2,
  GetTerminal = 3,
  DetCatalog = 4,
}

@Injectable({
  providedIn: 'root'
})
export class TerminalService {


  // MAIN OBSERVABLE ===========================================================
  private eventSource = new Subject<any>();
  public eventSource$ = this.eventSource.asObservable();

  uri = environment.APIEndpoint;

  constructor(
    private http: HttpClient,
    private log: LogServiceService,
  ) { }

  public async upseTermi(data) {
    let retVal: any = {};
    let response = null;
    try {
      response = await this.http.post(`${this.uri}/corps/terminal/upse`, data).toPromise();
      retVal = response;
    } catch (e) {
      this.log.show('Error');
    }
    this.eventSource.next({
      event: TerminalEvents.UpsertDone,
      data: retVal
    });
    return retVal;
  }

  public async terminalGetById(id) {
    let response = null;
    try {
      response = await this.http.post(`${this.uri}/corps/terminal/getById/${id}`, null).toPromise();
    } catch (e) {
      this.log.show('Error');
    }
    this.eventSource.next({
      event: TerminalEvents.GetById,
      data: response
    });
    return response;
  }

  public async getAllCatalog(id) {
    let retVal: any = {};
    let response = null;
    try {
      response = await this.http.get(`${this.uri}/iphadm/getterminal/${id}`).toPromise();
      // estadoCivil
      // grupoSangre
      // factorRH
    } catch (e) {
      this.log.show('Error');
    }
    this.eventSource.next({
      event: TerminalEvents.DetCatalog,
      data: response
    });
    return retVal;
  }

  public async getTerminal() {
    let response = null;
    try {
      response = await this.http.get(`${this.uri}/corps/getTerminal`).toPromise();
    } catch (e) {
      this.log.show('Error');
    }
    this.eventSource.next({
            event: TerminalEvents.GetTerminal,
            data: response
          });
    return response;
  }

  public async grid1RemoveRow(id) {
    let response = null;
    try {
      response = await this.http.get(`${this.uri}/corps/rem/${id}`).toPromise();
    } catch (e) {
      this.log.show('Error');
    }
    return response;
  }

}

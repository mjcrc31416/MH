export const NACIONALIDAD = [
  {
    nom: 'MEXICANA',
    cve: 1
  },
  {
    nom: 'EXTRANJERA',
    cve: 2
  }
];

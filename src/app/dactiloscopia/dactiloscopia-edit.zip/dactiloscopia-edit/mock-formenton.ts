export const FORMENTON = [
  {
    nom: 'OVAL',
    cve: 1
  },
  {
    nom: 'CUADRADO',
    cve: 2
  },
  {
    nom: 'EN PUNTA',
    cve: 3
  },
  {
    nom: 'VERTICAL',
    cve: 4
  }
];

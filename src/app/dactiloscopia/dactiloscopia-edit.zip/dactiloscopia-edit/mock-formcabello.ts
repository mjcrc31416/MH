export const FORMCABELLO = [
  {
    nom: 'CHINO',
    cve: 1
  },
  {
    nom: 'COLA',
    cve: 2
  },
  {
    nom: 'CRESPO',
    cve: 3
  },
  {
    nom: 'LACIO',
    cve: 4
  },
  {
    nom: 'ONDULADO',
    cve: 5
  },
  {
    nom: 'QUEBRADO',
    cve: 6
  },
  {
    nom: 'RIZADO',
    cve: 7
  },
  {
    nom: 'SIN CUIDAR',
    cve: 8
  },
  {
    nom: 'TINTE',
    cve: 9
  },
  {
    nom: 'TRENZA',
    cve: 10
  },
  {
    nom: 'OTRO ESTILO',
    cve: 11
  }
];

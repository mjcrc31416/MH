export const MENTON = [
  {
    nom: 'BILOVADO',
    cve: 1
  },
  {
    nom: 'FOSETA',
    cve: 2
  },
  {
    nom: 'BORLA',
    cve: 3
  },
  {
    nom: 'OVAL',
    cve: 4
  },
  {
    nom: 'CUADRADO',
    cve: 5
  },
  {
    nom: 'ISLOTE',
    cve: 6
  },
  {
    nom: 'NINGUNO',
    cve: 7
  }
];

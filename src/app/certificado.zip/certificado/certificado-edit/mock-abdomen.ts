export const ABDOMEN = [
  {
    abdomen: 'SIN COMPROMISO',
    cve: 1
  },
  {
    abdomen: 'CON COMPROMISO',
    cve: 2
  }
];


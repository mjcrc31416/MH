export const TIPCARA = [
  {
    nom: 'REDONDO',
    cve: 1
  },
  {
    nom: 'ALARGADO',
    cve: 2
  },
  {
    nom: 'RECTANGULO',
    cve: 3
  },
  {
    nom: 'CUADRADO',
    cve: 4
  },
  {
    nom: 'TRIÁNGULO',
    cve: 5
  },
  {
    nom: 'TRIÁNGULO INVERTIDO',
    cve: 6
  },
  {
    nom: 'CORAZÓN',
    cve: 7
  },
  {
    nom: 'DIMANTE',
    cve: 8
  },
  {
    nom: 'OVALADO',
    cve: 9
  }
];

export const OCUPACION = [
  {
    nom: 'EMPLEADO',
    cve: 1
  },
  {
    nom: 'DESEMPLEADO',
    cve: 2
  }
];

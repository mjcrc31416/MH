export const CARDIO = [
  {
    cardiopul: 'SIN COMPROMISO',
    bid: 1
  },
  {
    cardiopul: 'CON COMPROMISO',
    bid: 2
  }
];


import { Component, OnInit, ViewChild } from '@angular/core';
import {Router} from '@angular/router';
import { TerminalService, TerminalEvents } from '../terminal.service';
import {Subscription} from 'rxjs';
import * as _ from 'lodash'; 
import { StdGrid2Component } from 'src/app/shared/std-grid2/std-grid2.component';
import { TerminalEditComponent } from '../terminal-edit/terminal-edit.component';
import {MatDialog} from '@angular/material';


@Component({
  selector: 'app-terminal-cons',
  templateUrl: './terminal-cons.component.html',
  styleUrls: ['./terminal-cons.component.scss']
})
export class TerminalConsComponent implements OnInit {


  refreshActive = false;
  columnDefs = [
    {
      headerName: "",
      field: "edit-icon",
      width: 40,
      cellRenderer: (params) => {
        return '<span><i style="font-size:9pt" class="material-icons">edit</i></span>';
      }
    },
    {
      headerName: "",
      field: "del-icon",
      width: 40,
      cellRenderer: (params) => {
        return '<span><i style="font-size:9pt" class="material-icons" >delete</i></span>';
      }
    },
    {headerName: 'Nombre', field: 'nombre'},
    {headerName: 'Marca', field: 'marca'},
    {headerName: 'Número de Inventario', field: 'noInventario'}
  ];

    // Grid Acciones ================================================
    @ViewChild('grid1', {static: false}) public  grid1: StdGrid2Component;
    grid1ColConfig = {
      edit: true,
      remove: true,
    };
    grid1SourceData = [];
    grid1ColDefs = [
      {headerName: 'Nombre', field: 'nombre'},
      {headerName: 'Marca', field: 'marca'},
      {headerName: 'Número de Inventario', field: 'noInventario'}
    ];
  
  public rowData: Array<any>;
  gridApi: any;
  api: any;
  gridOptions: any;

  private subs: Subscription = new Subscription();
  
  constructor( 
    private router: Router,
    public dialog: MatDialog,
    private terminalSrv: TerminalService,
    )
  {
    this.subs.add(
      this.terminalSrv.eventSource$.subscribe((data) => {
          this.dispatchEvents(data);
        }
      ));
      
  }

  ngOnInit() {
    this.terminalSrv.getTerminal();
  }

  setData(data) {
    this.grid1.setDataSource(data.data);
  }

  onNuevo() {
    this.router.navigate(['terminal', '0']);
  }

  onActualizar() {
    if (!this.refreshActive) {
      this.refreshActive = true;
      this.terminalSrv.getTerminal().then(
        (data) => {
          this.grid1SourceData = data;
          this.refreshActive = false;
        }
      );
    }
  }

  grid1RemoveRow(data) {
    const newSourceData = this.grid1.removeFromGrid(data.data);
    const res = confirm('¿Está seguro de eliminar el elemento seleccionado?');

    this.grid1SourceData = newSourceData;

    this.terminalSrv.grid1RemoveRow(data.data._id).then((data) => {
      console.log(data);
    });
  }

  grid1EditRow(data) {
    console.log(data);
    this.router.navigate(['/terminal', data.data._id]);
    this.terminalSrv.getTerminal();
  }


  afterGetRejectedList(data) {
    this.grid1.setNewData(data);
  }
  
  // SERVICE EVENTS =======================================================================
  dispatchEvents(data) {
    console.log('dispatchEvents');
    //   Evento para el catáogo de Reportas
    if (data.event === TerminalEvents.GetTerminal) {
      console.log(data);
      //this.rowData = data.data;
      this.grid1.setDataSource(data.data);
    }
  }

}

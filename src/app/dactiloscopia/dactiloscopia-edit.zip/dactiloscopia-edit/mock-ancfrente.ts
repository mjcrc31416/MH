export const ANCFRENTE = [
  {
    nom: 'ANGOSTA',
    cve: 1
  },
  {
    nom: 'MEDIA',
    cve: 2
  },
  {
    nom: 'ANCHA',
    cve: 3
  }
];

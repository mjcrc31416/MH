import { Component, OnInit } from '@angular/core';
import {ActionBarItemModel, barActions} from '../../../shared/action-bar2/action-bar-model';
import {FormBuilder, Validators} from '@angular/forms';
import {SnackSrvService} from '../../../services/snack-srv.service';
import {ActivatedRoute, ParamMap, Router} from '@angular/router';
import {PersonalEvents, PersonalService} from '../personal.service';
import * as _ from 'lodash';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-personal-edit',
  templateUrl: './personal-edit.component.html',
  styleUrls: ['./personal-edit.component.scss']
})

export class PersonalEditComponent implements OnInit {

  // Action Bar Events ====================================================================

  onActionClicked(item: ActionBarItemModel) {
    if (item.id === barActions.show) {
      // this.toogleMostar();
    }

    if (item.id === barActions.save) {
      if (!this.isSavingData) {
        this.isSavingData = true;
        this.attemptSave();
      }
    }

    if (item.id === barActions.exit) {
      // if (!this.isSavingData) {
      //   // this.atttemptApprove();
      // }
      console.log('action exit');
      this.onExit();
    }

    if (item.id === barActions.send) {
      if (!this.isSavingData) {
        // this.atttemptApprove();
      }

    }
  }

  onExit() {
    this.router.navigate(['personal-cons']);
  }


  attemptSave() {
    console.log('attemptSave');
    if (!this.isSavingData) {
      if (this.form.valid) {
        console.log('Is valid!');
        const data = this.form.getRawValue();
        console.log(data);

        if (!_.isNil(this._id)) {
          data._id = this._id;
        }

        data.corporacion.unidad = data.unidad;
        this.personalSrv.upsertPersonal(data);
        this.snackSrv.showMsg('Información guardada correctamente');
      } else {
        this.snackSrv.showMsg('Faltan campos obligatorios');
      }

      this.isSavingData = false;
    }//endIf
  }

  // Atributos ======================================================================
  form = this.fb.group({
    datPer: this.fb.group({
      nombre: ['', Validators.required],
      appat: ['', Validators.required],
      apmat: ['', Validators.required],
      fecnac: ['', Validators.required],
      rfc: ['', Validators.required],
      curp: ['', Validators.required],
      sexo: ['', Validators.required],
      estadoCivil: ['', Validators.required],
      grupoSangre: ['', Validators.required],
      factorRH: ['', Validators.required],
    }),
    cve: ['', Validators.required],
    corporacion: ['', Validators.required],
    unidad: ['', Validators.required],
    grado: ['', Validators.required],
  });

  grupoSanguineo = [
    {
      nombre: 'test'
    }
  ];

  corporaciones = [];
  unidades = [];
  grados = [];
  sexos = [];
  estadoCiviles = [];
  grupoSangres = [];
  factorRHs = [];
  _id;
  isSavingData = false;


  private subs: Subscription = new Subscription();

  constructor(
    private snackSrv: SnackSrvService,
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private personalSrv: PersonalService
  ) {
    this.subs.add(
      this.personalSrv.eventSource$.subscribe((data) => {
          this.dispatchEvents(data);
        }
      ));
  }

  ngOnInit() {
    const tempProm = this.route.paramMap.subscribe( (params: ParamMap) => {
      console.log(params);
      const id = params.get('id');

      if (id && id !== '0') {
        // Obtener del servidor
        // this.ctrlSrv.getEventById(id);
        // this.eventoSrv.getEventoById(id);
        // this.isEdit = true;
        this._id = id;
      } else {
        // Es un nuevo elemento de captura
        // this.ctrlSrv.newEvent();
        // this.newItemDefaults();
      }
    });

    this.personalSrv.getAllCatalog('5dfd07748a890cafc369be8b');
  }

  // AUXILIAR EVENTS ======================================================================
  prepareSetData(data) {
    console.log(data);
    data.datPer.sexo = this.findComboValue(this.sexos, data.datPer.sexo, 'cve');
    data.datPer.estadoCivil = this.findComboValue(this.estadoCiviles, data.datPer.estadoCivil, 'cve');
    data.datPer.grupoSangre = this.findComboValue(this.grupoSangres, data.datPer.grupoSangre, 'cve');
    data.datPer.factorRH = this.findComboValue(this.factorRHs, data.datPer.factorRH, 'cve');
    data.datPer.factorRH = this.findComboValue(this.factorRHs, data.datPer.factorRH, 'cve');

    data.unidad = this.findComboValue(this.unidades, data.corporacion.unidad, 'cve');
    data.grado = this.findComboValue(this.grados, data.grado, 'cveGrado');
    data.corporacion = this.corporaciones[0];
    return data;
  }

  findComboValue(listData, setObjData, attributeName) {
    try {
      for (let data of listData) {
        if (data[attributeName] === setObjData[attributeName]) {
          return data;
          break;
        }
      }
    } catch(e) {
      console.log(listData);
      console.log(setObjData);
      console.log(attributeName);
    }

    return null;
    
  }

  // SERVICE EVENTS =======================================================================
  dispatchEvents(data) {
    console.log('dispatchEvents');
    // Evento
    if (data.event === PersonalEvents.CorpCatalog) {
      console.log(data);
      if (data.data.corp) {
        this.unidades = data.data.corp[0].unis;
        this.grados = data.data.corp[0].grados;
        this.sexos = data.data.sexos;
        this.estadoCiviles = data.data.estadoCiviles;
        this.grupoSangres = data.data.grupoSangres;
        this.factorRHs = data.data.factorRHs;
        this.corporaciones = [data.data.corp[0]];
        this.form.get('corporacion').patchValue(this.corporaciones[0]);
      }

      if (this._id) {
        this.personalSrv.personalGetById(this._id);
      }

    }//endIf

    if (data.event === PersonalEvents.UpsertPersonal) {
      console.log(data);
      if (data.data) {
        this._id = data.data._id;
      }
    }//endIf

    if (data.event === PersonalEvents.GetById) {
      this.form.patchValue(this.prepareSetData(data.data[0]));
    }//endIf
  }

}

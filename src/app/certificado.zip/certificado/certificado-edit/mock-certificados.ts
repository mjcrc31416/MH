export const CERTIFICADO = [
  {
    tcertificado: 'ÚNICO',
    bid: 1
  },
  {
    tcertificado: 'SÁLIDA',
    bid: 2
  }
];

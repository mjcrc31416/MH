import {AfterViewInit, Component, OnDestroy, OnInit} from '@angular/core';
import {ActionBarItemModel, barActions} from '../../shared/action-bar2/action-bar-model';
import {FormBuilder, Validators} from '@angular/forms';
import {SnackSrvService} from '../../services/snack-srv.service';
import {ActivatedRoute, ParamMap, Router} from '@angular/router';
import * as _ from 'lodash';
import {Subscription} from 'rxjs';
import { NumberSequence } from 'ag-grid-community';
import {FormUtilsService} from '../../shared/form-utils.service';
import { TerminalService, TerminalEvents } from '../terminal.service';
import { distinct } from 'rxjs/operators';


@Component({
  selector: 'app-terminal-edit',
  templateUrl: './terminal-edit.component.html',
  styleUrls: ['./terminal-edit.component.scss']
})
export class TerminalEditComponent implements OnInit, OnDestroy {
  noAleatorio;

  // Action Bar Events ====================================================================
  orgData = null;
  titlesList = ['Terminales', 'Edición'];
  showActionList = [1, 4];
  isSavingData: any;

  onActionClicked(item: ActionBarItemModel) {
    if (item.id === barActions.show) {
      // this.toogleMostar();
    }

    if (item.id === barActions.save) {
      this.attemptSave();
    }

    if (item.id === barActions.exit) {
      // if (!this.isSavingData) {
      //   // this.atttemptApprove();
      // }
      console.log('action exit');
      this.onExit();
    }

    if (item.id === barActions.send) {
      if (!this.isSavingData) {
        // this.atttemptApprove();
      }
    }
  }

  onExit() {
    this.router.navigate(['terminal-cons']);
  }

  attemptSave() {
    console.log('attemptSave');
    if (!this.isSavingData) {
      if (this.form.valid) {
        console.log('Is valid!');
        const data = this.form.getRawValue();
        console.log(data);

        if (!_.isNil(this._id)) {
          data._id = this._id;
        }

        this.terminalSrv.upseTermi(data);
      } else {
        this.snackSrv.showMsg('Faltan campos obligatorios');
      }

      this.isSavingData = false;
    }//endIf
  }

  // Atributos ======================================================================
  form = this.fb.group({
    nombre: ['', Validators.required],
    uuid: [{value: '', disabled: true}, ],
    marca: ['', Validators.required],
    noInventario: ['', Validators.required],
    noAleatorio: [{value: '', disabled: true}, ],
  });

  _id;

  private subs: Subscription = new Subscription();

  constructor(
    private snackSrv: SnackSrvService,
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private formUtils: FormUtilsService,
    private terminalSrv: TerminalService,
  ) {
    this.subs.add(
      this.terminalSrv.eventSource$.subscribe((data) => {
          this.dispatchEvents(data);
        }
      ));
  }

  ngOnInit() {

    // Tomar número y asignarlos automaticamente
    let tmpStr = this.formUtils.getNewId();
    console.log(tmpStr.substr(tmpStr.length-6, 6));
    tmpStr = tmpStr.substr(tmpStr.length-6, 6);

    // ASIGNA EL VALOR DE LA VARIABLE OBTENIDA
    this.form.get('noAleatorio').patchValue(tmpStr);

    const tempProm = this.route.paramMap.subscribe( (params: ParamMap) => {
      console.log(params);
      const id = params.get('id');

      if (id && id !== '0') {
        // Obtener del servidor
        // this.ctrlSrv.getEventById(id);
        // this.eventoSrv.getEventoById(id);
        // this.isEdit = true;
        this._id = id;
      } else {
        // Es un nuevo elemento de captura
        // this.ctrlSrv.newEvent();
        // this.newItemDefaults();
      }
    });

  }

  ngOnDestroy(): void {
    if (this.subs) {
      this.subs.unsubscribe();
    }
  }

  findComboValue(listData, setObjData, attributeName) {
try {
  for (let data of listData) {
    if (data[attributeName] === setObjData[attributeName]) {
      return data;
      break;
    }
  }
} catch (error) {
  return null;
}

  }

  // SERVICE EVENTS =======================================================================
  dispatchEvents(data) {
    console.log('dispatchEvents');
    if (data.event === TerminalEvents.DetCatalog) {
      console.log(data);
      if (data.data) {
        const response = data.data;
        console.log('Martinillo');
        console.log(response);

        //this.sexo = response[0].sexo;
         this.form.patchValue(response);
         console.log('Martinillo desde Chiquillo');

      /*if (this._id) {
        this.certificadoSrv.getAllCatalog(this._id);
      }*/
      return;
    }//endIf

    if (data.event === TerminalEvents.UpsertDone) {
      console.log(data);
      if (data.data) {

        this._id = data.data._id;
        this.snackSrv.showMsg('Información guardada correctamente');
      }

      return;
    }//endIf

    if (data.event === TerminalEvents.GetById) {
      console.log(data);
      if (data.data) {
        const response = data.data;
        console.log(response);

        this.form.patchValue(response);
        
      }
      // this.form.patchValue(data.data);
      return;
    }//endIf

  }
  }

}

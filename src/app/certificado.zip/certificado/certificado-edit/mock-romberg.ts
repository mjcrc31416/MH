export const ROMBERG = [
  {
    romberg: 'POSITIVO',
    cve: 1
  },
  {
    romberg: 'NEGATIVO',
    bid: 2
  }
];

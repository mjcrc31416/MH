export const ALERGIAS = [
  {
    alergias: 'SI',
    cve: 1
  },
  {
    alergias: 'NO',
    cve: 2
  }
];

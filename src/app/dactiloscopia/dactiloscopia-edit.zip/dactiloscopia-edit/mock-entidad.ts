export const ENTIDAD = [
  {
    nom: 'NUEVO LEÓN',
    cve: 1
  }
];

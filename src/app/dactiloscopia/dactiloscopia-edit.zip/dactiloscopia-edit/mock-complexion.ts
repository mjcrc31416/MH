export const COMPLEXION = [
  {
    nom: 'DELGADO',
    cve: 1
  },
  {
    nom: 'ATLETICO',
    cve: 2
  },
  {
    nom: 'REGULAR',
    cve: 3
  },
  {
    nom: 'ROBUSTO',
    cve: 4
  },
  {
    nom: 'OBESO',
    cve: 5
  }
];

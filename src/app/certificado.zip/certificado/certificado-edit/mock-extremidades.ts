export const EXTREMIDADES = [
  {
    extremidades: 'SIN COMPROMISO',
    cve: 1
  },
  {
    extremidades: 'CON COMPROMISO',
    bid: 2
  }
];


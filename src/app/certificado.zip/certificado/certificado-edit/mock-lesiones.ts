export const LESIONES = [
  {
    lesiones: 'NO PRESENTA',
    cve: 1
  },
  {
    lesiones: 'SI PRESENTA',
    bid: 2
  }
];

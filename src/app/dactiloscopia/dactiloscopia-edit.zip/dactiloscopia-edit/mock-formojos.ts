export const FORMOJOS = [
  {
    nom: 'OJOS JUNTOS',
    cve: 1
  },
  {
    nom: 'OJOS HUNDIDOS',
    cve: 2
  },
  {
    nom: 'ALMENDRADOS',
    cve: 3
  },
  {
    nom: 'OJOS SALTONES',
    cve: 4
  },
  {
    nom: 'PARPADO CAIDO',
    cve: 5
  },
  {
    nom: 'MONOPARPADO',
    cve: 6
  },
  {
    nom: 'OJOS SEPARADOS',
    cve: 7
  }
];

export const ALTERACIONES = [
  {
    alteraciones: 'SIN ALTERACIONES',
    cve: 1
  },
  {
    alteraciones: 'CON ALTERACIONES',
    cve: 2
  }
];


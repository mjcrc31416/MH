export const ALIENTO = [
  {
    aliento: 'NEGATIVO',
    cve: 1
  },
  {
    aliento: 'CON ALIENTO ALCOHOLICO',
    bid: 2
  },
  {
    aliento: 'EBRIEDAD INCOMPLETA',
    bid: 3
  },
  {
    aliento: 'EBRIO COMPLETO',
    bid: 3
  }
];

export const SEXO = [
  {
    nom: 'MUJER',
    cve: 1
  },
  {
    nom: 'HOMBRE',
    cve: 2
  },
  {
    nom: 'NO ESPECIFICADO',
    cve: 3
  }
];
export const COLOJOS = [
  {
    nom: 'AZULES',
    cve: 1
  },
  {
    nom: 'CAFE CLARO',
    cve: 2
  },
  {
    nom: 'CAFE OBSCURO',
    cve: 3
  },
  {
    nom: 'GRISES',
    cve: 4
  },
  {
    nom: 'NEGROS',
    cve: 5
  },
  {
    nom: 'VERDES',
    cve: 6
  }
];

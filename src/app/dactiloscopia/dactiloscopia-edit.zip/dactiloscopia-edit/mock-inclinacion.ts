export const INCLINACION = [
  {
    nom: 'HEYENTE',
    cve: 1
  },
  {
    nom: 'PROMINENTE',
    cve: 2
  },
  {
    nom: 'VERTICAL',
    cve: 3
  },
  {
    nom: 'RECTO',
    cve: 4
  }
];

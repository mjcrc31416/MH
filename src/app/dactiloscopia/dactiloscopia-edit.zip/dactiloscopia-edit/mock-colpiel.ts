export const COLPIEL = [
  {
    nom: 'ALBINO',
    cve: 1
  },
  {
    nom: 'BLANCO',
    cve: 2
  },
  {
    nom: 'MORENO',
    cve: 3
  },
  {
    nom: 'MORENO CLARO',
    cve: 4
  },
  {
    nom: 'NEGRO',
    cve: 5
  },
  {
    nom: 'PELIROJO',
    cve: 6
  },
  {
    nom: 'VITILIGO',
    cve: 7
  }
];

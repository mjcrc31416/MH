// DB.js
module.exports = {
  // DB: 'mongodb+srv://webapp1:Passw0rd@cacfmdb-xqpzb.mongodb.net/app2?retryWrites=true&w=majority'
  DB: 'mongodb://8affb522-0ee0-4-231-b9ee:JxtdqZ98he2hxfeaWOzUW7lGBs63wcGPHo28zjWE3Bd8qOTOy5w56wPaVzoazRQSO3eeZ5DUWVTw1bWU2s8BXA%3D%3D@8affb522-0ee0-4-231-b9ee.documents.azure.com:10255/?ssl=true'
};

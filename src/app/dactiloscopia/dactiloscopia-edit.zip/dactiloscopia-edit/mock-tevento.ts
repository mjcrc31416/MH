export const TEVENTO = [
  {
    nom: 'ADMINISTRATIVO',
    cve: 1
  },
  {
    nom: 'MINISTERIO PÚBLICO',
    cve: 2
  }
];

export const COLCABELLO = [
  {
    nom: 'ALBINO',
    cve: 1
  },
  {
    nom: 'AZUL',
    cve: 2
  },
  {
    nom: 'CABELLO TEÑIDO',
    cve: 3
  },
  {
    nom: 'CABELLO CLARO',
    cve: 4
  },
  {
    nom: 'CABELLO OBSCURO',
    cve: 5
  },
  {
    nom: 'CASTAÑO ROJIZO',
    cve: 6
  },
  {
    nom: 'ENTRE CANO',
    cve: 7
  },
  {
    nom: 'NEGRO',
    cve: 8
  },
  {
    nom: 'RUBIO',
    cve: 9
  },
  {
    nom: 'CANOSO',
    cve: 10
  },
  {
    nom: 'OTRO COLOR',
    cve: 11
  }
];

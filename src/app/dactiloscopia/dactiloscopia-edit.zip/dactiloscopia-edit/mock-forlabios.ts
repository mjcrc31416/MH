export const FORLABIOS = [
  {
    nom: 'LABIO INFERIOR FINO',
    cve: 1
  },
  {
    nom: 'LABIO SUPERIOR FINO',
    cve: 2
  },
  {
    nom: 'LABIOS OVALES',
    cve: 3
  },
  {
    nom: 'LABIOS CAÍDOS',
    cve: 4
  },
  {
    nom: 'LABIO FINOS',
    cve: 5
  },
  {
    nom: 'LABIO GRUESOS',
    cve: 6
  },
  {
    nom: 'LABIO PUNTIAGUDOS',
    cve: 7
  },
  {
    nom: 'LABIO ASIMÉTRICOS',
    cve: 7
  }
];

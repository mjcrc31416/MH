export const INTOXICACION = [
  {
    intetil: 'SIN DATOS DE INTOXICACIÓN',
    cve: 1
  },
  {
    intetil: 'CON DATOS DE INTOXICACIÓN',
    bid: 2
  }
];

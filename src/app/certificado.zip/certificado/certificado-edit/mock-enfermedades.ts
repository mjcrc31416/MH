export const ENFERMEDADES = [
  {
    enfermedades: 'POSITIVO',
    cve: 1
  },
  {
    enfermedades: 'NEGATIVO',
    cve: 2
  }
];

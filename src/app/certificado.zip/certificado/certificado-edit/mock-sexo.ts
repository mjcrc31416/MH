export const SEXO = [
  {
    sexo: 'MUJER',
    bid: 1
  },
  {
    sexo: 'HOMBRE',
    bid: 2
  },
  {
    sexo: 'NO ESPECIFICADO',
    bid: 3
  }
];
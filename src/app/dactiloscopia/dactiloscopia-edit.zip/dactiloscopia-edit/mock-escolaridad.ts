export const ESCOLARIDAD = [
  {
    nom: 'PREESCOLAR',
    cve: 1
  },
  {
    nom: 'PRIMARIA',
    cve: 2
  },
  {
    nom: 'SECUNDARIA',
    cve: 3
  },
  {
    nom: 'MEDIA SUPERIOR',
    cve: 4
  },
  {
    nom: 'SUPERIOR',
    cve: 5
  },
  {
    nom: 'POSGRADO',
    cve: 6
  }
];

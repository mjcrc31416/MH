export const PERFORACIONES = [
  {
    perforaciones: 'NO PRESENTA',
    cve: 1
  },
  {
    perforaciones: 'SI PRESENTA',
    cve: 2
  }
];

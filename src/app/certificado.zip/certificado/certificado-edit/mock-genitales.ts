export const GENITALES = [
  {
    genitales: 'VALORADO',
    cve: 1
  },
  {
    genitales: 'NO VALORADO',
    cve: 2
  }
];


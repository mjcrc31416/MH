export const OROFARINGE = [
  {
    orofaringe: 'ALTERADO',
    cve: 1
  },
  {
    orofaringe: 'NORMAL',
    cve: 2
  }
];
export const EDOCIVIL = [
  {
    nom: 'SOLTERO',
    cve: 1
  },
  {
    nom: 'CASADO',
    cve: 2
  },
  {
    nom: 'VIUDO',
    cve: 3
  },
  {
    nom: 'DIVORCIADO',
    cve: 4
  },
  {
    nom: 'UNION LIBRE',
    cve: 5
  }
];

export const PRACTICA = [
  {
    practica: 'EXAMÉN MÉDICO',
    cve: 1
  }
];

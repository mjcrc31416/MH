export const CANCABELLO = [
  {
    nom: 'CALVO',
    cve: 1
  },
  {
    nom: 'POCO CABELLO',
    cve: 2
  },
  {
    nom: 'REGULAR',
    cve: 3
  },
  {
    nom: 'ABUNDANTE',
    cve: 4
  }
];

export const ALTFRENTE = [
  {
    nom: 'CHICA',
    cve: 1
  },
  {
    nom: 'MEDIANA',
    cve: 2
  },
  {
    nom: 'GRANDE',
    cve: 3
  }
];

export const MUNICIPIO = [
  {
    nom: 'Monterrey',
    cve: 1
  },
  {
    nom: 'Abasolo',
    cve: 2
  },
  {
    nom: 'Agualeguas',
    cve: 3
  },
  {
    nom: 'Allende',
    cve: 4
  },
  {
    nom: 'Anáhuac',
    cve: 5
  },
  {
    nom: 'Apodaca',
    cve: 6
  }
];

export const ALCOHOLISMO = [
  {
    alcoholismo: 'POSITIVO CRONICO',
    cve: 1
  },
  {
    alcoholismo: 'DE ALTA EVOLUCIÓN',
    bid: 2
  }
];


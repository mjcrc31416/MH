export const TOXICOMANIA = [
  {
    toxicomania: 'SI',
    cve: 1
  },
  {
    toxicomania: 'NO',
    cve: 2
  }
];

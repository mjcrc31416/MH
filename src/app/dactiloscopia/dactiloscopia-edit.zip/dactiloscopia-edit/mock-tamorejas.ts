export const TAMOREJAS = [
  {
    nom: 'PEQUEÑOS',
    cve: 1
  },
  {
    nom: 'MEDIANOS',
    cve: 2
  },
  {
    nom: 'GRANDES',
    cve: 3
  }
];
